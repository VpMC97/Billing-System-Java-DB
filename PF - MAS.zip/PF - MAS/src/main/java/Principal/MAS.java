
package Principal;

import Vista.F_Menu_3597;

public class MAS {

    public static void main(String[] args){
        F_Menu_3597 menu = new F_Menu_3597();
    }
}
